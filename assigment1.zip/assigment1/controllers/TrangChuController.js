window.TrangChuController = function($scope) {
    $scope.thongtin = "THÔNG TIN";

    //
    $scope.sanpham = [{
            name: "Hà nội đến sài gòn",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_tp_ho_chi_minh_saigon_d3b91cdfa6.jpg"
        },
        {
            name: "TP.HCM đến Hà Nội",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_hanoi_ba7693c643.jpg"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_da_nang_banner_22886e87cc_2_c65a071e7f.png"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_tp_ho_chi_minh_saigon_d3b91cdfa6.jpg"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_tp_ho_chi_minh_saigon_d3b91cdfa6.jpg"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_banner_phu_quoc_a03ff3f0a9_ea4c286d9f.png"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_da_nang_banner_22886e87cc_2_c65a071e7f.png"
        },
        {
            name: "Hà Nội đến Đà Nẵng",
            date: "10-10-2023",
            price: "500.000",
            image: "https://bav-ui.useleadr.com/uploads/medium_tp_ho_chi_minh_saigon_d3b91cdfa6.jpg"
        },

    ]
}