window.GioiThieuController = function($scope, $routeParams) {
    $scope.datve = "ĐẶT VÉ"

    // $routeParams: để lấy dữ liệu trên url
    $scope.id = $routeParams.id;
}